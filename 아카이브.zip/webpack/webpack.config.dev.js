const path = require('path');
const { HotModuleReplacementPlugin } = require('webpack');

module.exports = {
  mode: 'development',
  devtool: 'inline-source-map',
  plugins: [
    new HotModuleReplacementPlugin(), // 개발 코드 수정시 자동 새로고침
  ],
  devServer: {
    host: '0.0.0.0', // 외부에서 개발 서버에 접속해서 테스트하기 위해서는 '0.0.0.0'으로 설정해야 한다.
    historyApiFallback: true, // 히스토리 API를 사용하는 SPA 개발시 설정한다. 404가 발생하면 index.html로 리다이렉트한다.
    inline: true, // inline:true상태에서만 hot로더 사용가능
    hot: true, // HotModuleReplacementPlugin 사용하여 자동새로고침 허용
    port: 3000,
    quiet: true, // 웹팩의 오류 또는 경고가 표시되지 않음
    open: true, // 웹페이지 자동 실행

    // openPage: 'media', // localhost:3000/media 자동실행시 초기 path
    // http2: true, // http2 사용 여부
    // proxy: {
    //   // 라이브방송 정보 조회
    //   '/api/*': {
    //     target: 'https://mpc-dev.tmon.co.kr',
    //     changeOrigin: true,
    //     pathRewrite: { '^/media': '' },
    //   },
    // },
  },
};
