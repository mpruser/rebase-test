/* eslint-disable import/no-extraneous-dependencies */
const path = require('path');
const TerserPlugin = require('terser-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');

module.exports = {
  mode: 'production',
  plugins: [new CleanWebpackPlugin()],
  optimization: {
    minimizer: [
      new TerserPlugin({
        terserOptions: {
          ecma: 2018,
          compress: {
            ecma: 5,
            inline: 2,
            // pure_funcs: ['window.console.log', 'console.log'], // console.log()만 제거
          },
          mangle: { safari10: true },
        },
        parallel: true, // 프로세스를 병렬로 사용할지 결정
        extractComments: 'all', // 주석을 별도의 .txt 파일에 따로 내보낼지
      }),
    ],
  },
};
