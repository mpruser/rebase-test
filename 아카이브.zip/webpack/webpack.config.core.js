const path = require('path');
const FriendlyErrorsWebpackPlugin = require('friendly-errors-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ESLintPlugin = require('eslint-webpack-plugin');
// const { DefinePlugin, ProvidePlugin } = require('webpack');
// const MiniCssExtractPlugin = require('mini-css-extract-plugin');

module.exports = function webpackConfigCore({ isEnvProduction }) {
  return {
    entry: {
      index: 'src/index.tsx',
    },
    output: {
      path: path.join(__dirname, '../dist'),
      pathinfo: false, // true면 포함 된 모듈에 대한 정보와 함께 번들에 주석을 포함하도록 webpack에 지시.
      filename: `src/js/[name]${isEnvProduction ? '.[contenthash:8]' : ''}.js`,
      chunkFilename: `src/js/[name]${isEnvProduction ? '.[contenthash:8]' : ''}.chunk.js`,
    },
    optimization: {
      splitChunks: {
        chunks: 'all',
      },
      // 어플리케이션이 메모리를 할당받고 실행되는 환경과 관련된 Runtime 코드들만 별도 분리
      // runtimeChunk: {
      //   name: (entrypoint) => `runtime-${entrypoint.name}`,
      // },
    },
    cache: {
      type: isEnvProduction ? 'filesystem' : 'memory',
    },
    resolve: {
      // node_modules에 있는 패키지를 인식하기 위한 설정
      modules: ['node_modules'],
      // 확장자를 자동으로인식 시키기 위한 설정(좌측 부터 우측순으로)
      extensions: ['.tsx', '.ts', 'jsx', '.js'],
      // import 경로를 줄이기 위한 alias 설정
      alias: {
        src: path.resolve(__dirname, '../src'),
      },
    },
    plugins: [
      new FriendlyErrorsWebpackPlugin(),
      new HtmlWebpackPlugin({
        inject: 'body', // 스크립트가 주입될 위치
        template: 'public/index.html',
      }),
      /** eslint loader에서 plugin으로 변경됨 */
      new ESLintPlugin({
        extensions: ['js', 'ts', 'jsx', 'tsx'],
        exclude: ['node_modules'],
      }),
    ],
    module: {
      rules: [
        /** SVG Loader */
        {
          test: /\.svg$/,
          use: [
            {
              loader: '@svgr/webpack',
              options: {
                // CSS로 사이즈를 변경할때 해당 옵션이 필요
                icon: true,
                // CSS에서 stroke, fill 색상을 변경하기 위해 사용(로더문제가 아닌 내부적인(개인적인) 개발방식 적용 방법)
                replaceAttrValues: {
                  '#none': 'none',
                  customColor: '#959DA6',
                },
              },
            },
            {
              loader: 'url-loader',
              options: {
                outputPath: 'src/img/',
                name: '[name].[ext]?[hash]',
                limit: 10000,
              },
            },
          ],
        },
        /* Image Loader */
        {
          test: /\.(jpe?g|gif|png)$/,
          use: {
            loader: 'url-loader',
            options: {
              outputPath: 'src/img/',
              name: '[name].[ext]?[hash]',
              limit: 10000,
            },
          },
        },
        /* Typescript Loader */
        {
          test: /\.(ts|tsx)?$/,
          enforce: 'pre', // babel-loader보다 먼저 실행
          exclude: /node_modules/,
          use: [
            {
              loader: 'ts-loader',
              options: {
                // 개발 환경에서는 전체 컴파일이 아닌 변경사항만 컴파일되도록 설정
                transpileOnly: !isEnvProduction,
              },
            },
          ],
        },
        /* Eslint Loader */
        {
          test: /\.(js|jsx|ts|tsx)$/,
          exclude: /node_modules/,
          loader: 'babel-loader',
        },
      ],
    },
  };
};
