export default (a: number, b: number) => a + b;
