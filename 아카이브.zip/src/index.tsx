/* eslint-disable import/extensions */
/* eslint-disable import/no-unresolved */
import get from 'lodash/get';
import add from './add';

window.console.log(123123123123123);
window.console.log(add(1, 2213123));
window.console.log(get({ a: 1, b: 2, c: 3 }, 'd', 2));
window.console.log(get({ a: 1, b: 2, c: 3 }, 'd', 2));
window.console.log(get({ a: 1, b: 2, c: 3 }, 'd', 2));
window.console.log(get({ a: 1, b: 2, c: 3 }, 'd', 2));
window.console.log(get({ a: 1, b: 2, c: 3 }, 'd', 2));
window.console.log(get({ a: 1, b: 2, c: 3 }, 'd', 2));
