const { merge } = require('webpack-merge');
const webpackConfigCore = require('./webpack/webpack.config.core');
const webpackConfigProd = require('./webpack/webpack.config.prod');
const webpackConfigDev = require('./webpack/webpack.config.dev');

const isEnvProduction = process.env.NODE_ENV === 'production';

module.exports = merge(
  webpackConfigCore({ isEnvProduction }),
  isEnvProduction ? webpackConfigProd : webpackConfigDev,
);
